// router.js
const vizMap = [
  {
    match: "https://www.jeffjianzhao.com/webapp/MatrixWave/matrixwave.html",
    file: "scripts/onboarding_matrixwave.js"
  },
  {
    match: "https://dongoa.github.io/VIStory/",
    file: "scripts/onboarding_vistory.js"
  },
  {
    match: "http://localhost:8000/",
    file: "scripts/onboarding_rulematrix.js"
  },
  {
    match: "https://attentionflow.cmlab.dev/#/overview/artist/UComP_epzeKzvBX156r6pm1Q",
    file: "scripts/onboarding_attentionflow.js"
  },
  {
    match: "https://poloclub.github.io/dodrio/",
    file: "scripts/onboarding_dodrio.js"
  },
  {
    match: "https://vcg.github.io/upset/",
    file: "scripts/onboarding_upset.js"
  },
  {
    match: "https://prettismart.onrender.com", 
    file: "scripts/onboarding_prettismart.js"
  },
  {
    match: "https://diffseer.github.io/",
    file: "scripts/onboarding_diffseer.js"
  },
  {
    match: "https://www.jeffjianzhao.com/webapp/EgoLines/egolines-demo.html",
    file: "scripts/onboarding_egolines.js"
  },
  {
    match: "https://www.jeffjianzhao.com/webapp/Pearl/pearl.html",
    file: "scripts/onboarding_pearl.js"
  },
  {
    match: "https://composite-visualization-gallery.onrender.com/html_files/multiple_bar_line.html",
    file: "scripts/onboarding_labelmania.js"
  },
  {
    match: "https://composite-visualization-gallery.onrender.com//html_files/candlestick-touch.html",
    file: "scripts\onboarding_candlestick.js"
  },
  {
    match: "http://localhost:8080/",
    file: "scripts/onboarding_ponzilens.js"
  },
  {
    match: "https://quantumeyes.github.io/",
    file: "scripts/onboarding_quantum.js"
  },
  {
    match: "https://composite-visualization-gallery.onrender.com//html_files/zingchart_1.html",
    file: "scripts/onboarding_timeline.js"
  },
  {
    match: "https://composite-visualization-gallery.onrender.com/html_files/mixedbar_staggeredline.html",
    file: "scripts/onboarding_mixedbar.js"
  },
  {
    match: "https://composite-visualization-gallery.onrender.com/html_files/multiple_time_series.html",
    file: "scripts/onboarding_multiline.js"
  },
  {
    match: "https://composite-visualization-gallery.onrender.com/html_files/candlestick-sh.html",
    file: "scripts/onboarding_shangai.js"
  },



];
// https://prettismart.onrender.com


const currentURL = window.location.href;

// Find which config matches the current URL
const activeViz = vizMap.find(item => currentURL.includes(item.match));

if (activeViz) {
  console.log("Router: Loading " + activeViz.file);
  
  // Create a script tag to inject the file
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL(activeViz.file);
  
  // This ensures the script runs in the context of the page
  (document.head || document.documentElement).appendChild(script);
  
  script.onload = function() {
    console.log("Router: Successfully loaded " + activeViz.file);
    this.remove(); // Clean up the tag after execution
  };
}