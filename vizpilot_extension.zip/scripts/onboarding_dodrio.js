(function() {
    // ==========================================
    // 1. DATA (Timeline Matrix Data)
    // ==========================================
    const RAW_STEPS = [{'step_id': 'step_1',
  'text': 'Start by glancing left to see the radial attention graph (colored token dots with arrows) and then look right to the donut grid of all heads; the highlighted donut determines which set of arrows you see on the left, and the color legend under the graph explains each token dot’s redness.',
  'targets': [],
  'actions': ['highlight-multiple'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_2',
  'text': 'Read each donut ring as one specific mark for a Layer × Head pair: rows are layers (see the layer numbers at left) and columns are heads (see the head numbers on top). The donut with the dark outlined box marks the active pair (here, Layer 10, Head 3).',
  'targets': {'view': {'candidates': [{'selector': 'g.donut-group',
      'confidence': 'high',
      'reason': 'container for the donut grid of attention heads'}]},
   'encoding': {'candidates': [{'selector': 'path.donut-chart',
      'confidence': 'high',
      'reason': 'donut arcs encode head metrics per layer/head cell'},
     {'selector': 'g.donut.selected path.donut-chart',
      'confidence': 'high',
      'reason': 'selected donut encoding with special styling'}]},
   'interaction': {'candidates': [{'selector': 'rect.donut-rect',
      'confidence': 'high',
      'reason': 'invisible rectangles used as clickable/hover targets per cell'},
     {'selector': 'g.donut[style*="cursor: pointer"]',
      'confidence': 'medium',
      'reason': 'interactive donut cell groups'}]}},
  'actions': ['highlight', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_3',
  'text': 'Interpret each token circle as a colored dot whose fill maps to the Semantic Saliency Score—match its redness to the legend from 0.00 (white) to 0.20 (deep red) to judge how semantically important that specific mark is.',
  'targets': {'view': {'candidates': [{'selector': 'g.node-group',
      'confidence': 'high',
      'reason': 'container grouping all node glyphs in the radial view'}]},
   'encoding': {'candidates': [{'selector': 'g.node > circle.node-circle',
      'confidence': 'high',
      'reason': 'circles encode token nodes (position/color/size)'},
     {'selector': 'g.node text.node-text',
      'confidence': 'medium',
      'reason': 'text labels encode node/token names'}]},
   'interaction': {'candidates': [{'selector': 'g.node',
      'confidence': 'medium',
      'reason': 'node groups act as hover/click targets for nodes'},
     {'selector': 'circle.node-circle',
      'confidence': 'medium',
      'reason': 'primary circle hit area for node interactions'}]}},
  'actions': ['highlight', 'glow', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_4',
  'text': 'Follow a single arrow to read attention: the arrow points from a source token dot to a target token dot, and thicker strokes indicate stronger attention weight; orange arrows show the currently highlighted connections while gray arrows show the rest.',
  'targets': {'view': {'candidates': [{'selector': 'g.attention-link-group',
      'confidence': 'high',
      'reason': 'container grouping all attention links'}]},
   'encoding': {'candidates': [{'selector': 'path.link',
      'confidence': 'high',
      'reason': 'paths encode directed attention links with width/color'},
     {'selector': 'path.link.highlighted',
      'confidence': 'medium',
      'reason': 'subset of links visually emphasized for selection/hover'}]},
   'interaction': {'candidates': [{'selector': 'path.link[marker-end="url(#arrow-hover)"]',
      'confidence': 'high',
      'reason': 'links using hover arrow marker indicate interactive highlight state'},
     {'selector': 'path.link.highlighted',
      'confidence': 'high',
      'reason': 'active/hovered link elements'}]}},
  'actions': ['highlight', 'glow', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_5',
  'text': 'Trace the orange arrows connected to the semicolon token (the specific mark with a white halo) and notice how several arrows fan from it to resource, ##ful, and hero while other arrows point into it from nearby subword dots—this head uses punctuation as a routing hub, a common “aha” pattern in attention graphs.',
  'targets': {'view': {'candidates': [{'selector': 'g.attention-link-group',
      'confidence': 'high',
      'reason': 'container grouping all attention links'}]},
   'encoding': {'candidates': [{'selector': 'path.link',
      'confidence': 'high',
      'reason': 'paths encode directed attention links with width/color'},
     {'selector': 'path.link.highlighted',
      'confidence': 'medium',
      'reason': 'subset of links visually emphasized for selection/hover'}]},
   'interaction': {'candidates': [{'selector': 'path.link[marker-end="url(#arrow-hover)"]',
      'confidence': 'high',
      'reason': 'links using hover arrow marker indicate interactive highlight state'},
     {'selector': 'path.link.highlighted',
      'confidence': 'high',
      'reason': 'active/hovered link elements'}]}},
  'actions': ['highlight', 'trace', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_6',
  'text': 'Scan the ring for the darkest token dots—complicated, bas, clever, scenery, and lavish stand out—which signals higher semantic saliency; use these specific marks to anchor where meaning concentrates in the sentence.',
  'targets': {'view': {'candidates': [{'selector': 'g.node-group',
      'confidence': 'high',
      'reason': 'container grouping all node glyphs in the radial view'}]},
   'encoding': {'candidates': [{'selector': 'g.node > circle.node-circle',
      'confidence': 'high',
      'reason': 'circles encode token nodes (position/color/size)'},
     {'selector': 'g.node text.node-text',
      'confidence': 'medium',
      'reason': 'text labels encode node/token names'}]},
   'interaction': {'candidates': [{'selector': 'g.node',
      'confidence': 'medium',
      'reason': 'node groups act as hover/click targets for nodes'},
     {'selector': 'circle.node-circle',
      'confidence': 'medium',
      'reason': 'primary circle hit area for node interactions'}]}},
  'actions': ['highlight', 'trace', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_7',
  'text': 'Click a donut ring to switch the active head; the chosen ring gains a dark outlined box and the arrows in the left graph update so you can compare how different heads distribute attention.',
  'targets': {'view': {'candidates': [{'selector': 'g.donut-group',
      'confidence': 'high',
      'reason': 'container for the donut grid of attention heads'}]},
   'encoding': {'candidates': [{'selector': 'path.donut-chart',
      'confidence': 'high',
      'reason': 'donut arcs encode head metrics per layer/head cell'},
     {'selector': 'g.donut.selected path.donut-chart',
      'confidence': 'high',
      'reason': 'selected donut encoding with special styling'}]},
   'interaction': {'candidates': [{'selector': 'rect.donut-rect',
      'confidence': 'high',
      'reason': 'invisible rectangles used as clickable/hover targets per cell'},
     {'selector': 'g.donut[style*="cursor: pointer"]',
      'confidence': 'medium',
      'reason': 'interactive donut cell groups'}]}},
  'actions': ['pulse', 'tooltip', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_8',
  'text': 'Hover or tap an individual token dot to highlight its outgoing or incoming arrows in orange; use this to follow where that specific mark attends and which tokens attend back.',
  'targets': {'view': {'candidates': [{'selector': 'g.attention-link-group',
      'confidence': 'high',
      'reason': 'container grouping all attention links'}]},
   'encoding': {'candidates': [{'selector': 'path.link',
      'confidence': 'high',
      'reason': 'paths encode directed attention links with width/color'},
     {'selector': 'path.link.highlighted',
      'confidence': 'medium',
      'reason': 'subset of links visually emphasized for selection/hover'}]},
   'interaction': {'candidates': [{'selector': 'path.link[marker-end="url(#arrow-hover)"]',
      'confidence': 'high',
      'reason': 'links using hover arrow marker indicate interactive highlight state'},
     {'selector': 'path.link.highlighted',
      'confidence': 'high',
      'reason': 'active/hovered link elements'}]}},
  'actions': ['pulse', 'tooltip', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}}];

    // ==========================================
    // 2. HELPER: UTILS (Your Generalization Logic)
    // ==========================================
    const Utils = {
        resolveSelector: (targets) => {
            if (!targets) return null;
            const priorities = ['view', 'encoding', 'interaction'];
            for (let type of priorities) {
                if (targets[type]?.candidates?.[0]?.selector) {
                    return targets[type].candidates[0].selector;
                }
            }
            return null;
        },
        generalizeLLMData: (rawSteps) => {
            const mergedData = new Map();
            const generateTitle = (candidate, defaultId) => {
                if (!candidate || !candidate.reason) return "Component: " + defaultId;
                let text = candidate.reason.toLowerCase().replace(/^(container for|wrapper of|main view of|view of|the)\s+/, '').split(' and ')[0];
                return text.replace(/\b\w/g, l => l.toUpperCase());
            };
            const categorizeText = (fullText) => {
                const sentences = fullText.match(/[^.?!]+[.?!]+|[^.?!]+$/g) || [];
                let buckets = { encoding: [], insight: [], interaction: [] };
                sentences.forEach(s => {
                    const l = s.toLowerCase().trim();
                    if (!l) return;
                    if (l.match(/(hover|click|drag|press|scroll|tooltip|select|toggle)/)) buckets.interaction.push(s.trim());
                    else if (l.match(/(look for|spot|compare|notice|reveal|identify|check|observe|pattern)/)) buckets.insight.push(s.trim());
                    else buckets.encoding.push(s.trim());
                });
                return {
                    encoding: buckets.encoding.join(' ') || "Visual encoding details.",
                    insight: buckets.insight.join(' ') || "Observe the data patterns displayed here.",
                    interaction: buckets.interaction.join(' ') || "Hover or click to interact."
                };
            };
            rawSteps.forEach(step => {
                let mainCandidate = step.targets?.view?.candidates?.[0] || step.targets?.encoding?.candidates?.[0];
                let key = mainCandidate ? mainCandidate.selector : 'General_Overview';
                if (!mergedData.has(key)) {
                    mergedData.set(key, { step_id: key, title: key === 'General_Overview' ? 'Dashboard Overview' : generateTitle(mainCandidate, step.step_id), rawText: '', targets: step.targets, selector: key });
                }
                mergedData.get(key).rawText += ' ' + step.text;
            });
            return Array.from(mergedData.values()).map(entry => ({ step_id: entry.step_id, title: entry.title, content: categorizeText(entry.rawText), targets: entry.targets, selector: entry.selector }));
        }
    };

    // ==========================================
    // 3. THE MANAGER (Controls the Toggle Flow)
    // ==========================================
    const OnboardingManager = {
        mode: 'none', // 'none', 'scrolly', 'explore'
        originalNodes: [], // Stores nodes to restore
        scrollyObserver: null,
        exploreHandler: null,
        
        init: function() {
            // --- A. Styles ---
            const style = document.createElement('style');
            style.id = 'ds-unified-style';
            style.textContent = `
                /* Top Toggle Bar */
                #ds-toggle-bar {
                    position: fixed; top: 20px; left: 50%; transform: translateX(-50%);
                    display: flex; background: #2c3e50; padding: 5px; border-radius: 30px;
                    box-shadow: 0 4px 15px rgba(0,0,0,0.3); z-index: 100000;
                }
                .ds-toggle-btn {
                    padding: 10px 20px; border: none; background: transparent; color: #bdc3c7;
                    font-family: sans-serif; font-weight: bold; font-size: 14px; cursor: pointer;
                    border-radius: 25px; transition: all 0.3s; outline: none;
                }
                .ds-toggle-btn.active { background: #3498db; color: white; box-shadow: 0 2px 10px rgba(0,0,0,0.2); }
                .ds-toggle-btn:hover:not(.active) { color: white; }

                /* Scrolly Styles */
                body.ds-scrolly-active { overflow: hidden; }
                #ds-left-pane { position: fixed; top: 0; left: 0; width: calc(100% - 300px); height: 100vh; overflow: auto; background: white; z-index: 9000; }
                #ds-right-pane { position: fixed; top: 0; right: 0; width: 300px; height: 100vh; overflow-y: scroll; background: #fcfcfc; border-left: 1px solid #eee; z-index: 9001; }
                #ds-scale-wrapper { transform-origin: top left; transition: transform 0.3s ease; padding: 20px; }
                .ds-step-container { min-height: 80vh; display: flex; align-items: center; padding: 20px; }
                .ds-step-content { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); opacity: 0.4; transition: all 0.3s; border-left: 4px solid transparent; }
                .ds-step-content.active { opacity: 1; border-left: 5px solid #9b59b6; transform: scale(1.02); }
                .ds-step-badge { background: #9b59b6; color: white; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: bold; text-transform: uppercase; margin-bottom: 8px; display: inline-block; }
                .ds-dim { opacity: 0.8 !important; transition: opacity 0.5s; }
                .ds-highlight { opacity: 1 !important; stroke: #9b59b6 !important; filter: none !important; }
                g.ds-highlight *, .ds-highlight * { opacity: 1 !important; fill-opacity: 1; stroke: #9b59b6 !important; }

                /* Inspector Styles */
                #ds-inspector { position: fixed; top: 100px; right: 20px; width: 300px; bottom: 20px; background: #1e1e1e; color: #d4d4d4; z-index: 10000; font-family: 'Segoe UI', sans-serif; box-shadow: 0 5px 25px rgba(0,0,0,0.3); border-radius: 8px; display: flex; flex-direction: column; opacity: 0; pointer-events: none; transition: opacity 0.3s; }
                #ds-inspector.visible { opacity: 1; pointer-events: auto; }
                .ds-header { padding: 15px 20px; background: #252526; border-bottom: 1px solid #333; border-radius: 8px 8px 0 0; }
                .ds-header h2 { margin: 0; font-size: 13px; text-transform: uppercase; color: #aaa; }
                .ds-content { padding: 20px; overflow-y: auto; flex: 1; }
                .ds-title { font-size: 18px; color: #fff; margin: 0 0 20px 0; font-weight: 600; border-bottom: 1px solid #333; padding-bottom: 10px; }
                .ds-section { margin-bottom: 24px; }
                .ds-section-label { color: #569cd6; font-size: 11px; font-weight: 700; text-transform: uppercase; margin-bottom: 8px; }
                .ds-section-text { font-size: 13.5px; line-height: 1.6; color: #cccccc; }
                .ds-highlight-ring { outline: 2px solid #569cd6; outline-offset: 3px; }
            `;
            document.head.appendChild(style);

            // --- B. Render Top Toggle ---
            const toggleBar = document.createElement('div');
            toggleBar.id = 'ds-toggle-bar';
            toggleBar.innerHTML = `
                <button class="ds-toggle-btn" id="ds-btn-scrolly">Guided Tour</button>
                <button class="ds-toggle-btn" id="ds-btn-explore">Free Exploration</button>
            `;
            document.body.appendChild(toggleBar);

            // --- C. Bind Events ---
            document.getElementById('ds-btn-scrolly').onclick = () => this.setMode('scrolly');
            document.getElementById('ds-btn-explore').onclick = () => this.setMode('explore');
        },

        setMode: function(newMode) {
            // If clicking the same mode, toggle it off (optional, here we just return)
            if (this.mode === newMode) return; 

            // 1. Teardown Current Mode
            if (this.mode === 'scrolly') this.teardownScrolly();
            if (this.mode === 'explore') this.teardownExplore();

            // 2. Update Buttons
            document.querySelectorAll('.ds-toggle-btn').forEach(b => b.classList.remove('active'));
            if (newMode === 'scrolly') document.getElementById('ds-btn-scrolly').classList.add('active');
            if (newMode === 'explore') document.getElementById('ds-btn-explore').classList.add('active');

            // 3. Init New Mode
            this.mode = newMode;
            if (newMode === 'scrolly') this.initScrolly();
            if (newMode === 'explore') this.initExplore();
        },

        // ==========================================
        // SCROLLY LOGIC
        // ==========================================
        initScrolly: function() {
            document.body.classList.add('ds-scrolly-active');
            
            // Capture original nodes (excluding our UI)
            this.originalNodes = Array.from(document.body.children).filter(n => 
                n.id !== 'ds-unified-style' && n.id !== 'ds-toggle-bar' && n.tagName !== 'SCRIPT'
            );

            const leftPane = document.createElement('div'); leftPane.id = 'ds-left-pane';
            const scaleWrapper = document.createElement('div'); scaleWrapper.id = 'ds-scale-wrapper';
            const rightPane = document.createElement('div'); rightPane.id = 'ds-right-pane';
            
            // Move Viz into Wrapper
            this.originalNodes.forEach(n => scaleWrapper.appendChild(n));
            leftPane.appendChild(scaleWrapper);
            document.body.appendChild(leftPane);
            document.body.appendChild(rightPane);

            // Render Steps
            RAW_STEPS.forEach((step, i) => {
                const div = document.createElement('div');
                div.className = 'ds-step-container';
                div.dataset.index = i;
                div.innerHTML = `<div class="ds-step-content"><div class="ds-step-badge">Step ${i+1}</div><div>${step.text}</div></div>`;
                rightPane.appendChild(div);
            });

            // Extra padding at bottom
            const endPad = document.createElement('div');
            endPad.style.height = "50vh";
            rightPane.appendChild(endPad);

            // Scaling
            const fitContent = () => {
                const svg = document.querySelector('svg');
                if(!svg) return;
                scaleWrapper.style.transform = 'scale(1)';
                const scale = Math.min(leftPane.offsetWidth / scaleWrapper.scrollWidth, leftPane.offsetHeight / scaleWrapper.scrollHeight) * 1.8;
                scaleWrapper.style.transform = `scale(${scale})`;
            };
            setTimeout(fitContent, 100);
            window.addEventListener('resize', fitContent);

            // Observer
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        document.querySelectorAll('.ds-step-content').forEach(c => c.classList.remove('active'));
                        entry.target.querySelector('.ds-step-content').classList.add('active');
                        
                        const index = entry.target.dataset.index;
                        const step = RAW_STEPS[index];
                        const svg = document.querySelector('svg');
                        
                        // Reset
                        svg.querySelectorAll('*').forEach(el => { el.classList.remove('ds-dim'); el.classList.remove('ds-highlight'); });

                        if (step.actions.includes('highlight')) {
                            svg.querySelectorAll('g, rect, path, circle, text, line').forEach(el => el.classList.add('ds-dim'));
                            const selector = Utils.resolveSelector(step.targets);
                            if (selector) {
                                svg.querySelectorAll(selector).forEach(el => {
                                    el.classList.remove('ds-dim'); el.classList.add('ds-highlight');
                                    let p = el.parentNode;
                                    while(p && p !== svg) { p.classList.remove('ds-dim'); p = p.parentNode; }
                                });
                            }
                        }
                    }
                });
            }, { root: rightPane, threshold: 0.6 });

            document.querySelectorAll('.ds-step-container').forEach(el => observer.observe(el));
            this.scrollyObserver = observer;
        },

        teardownScrolly: function() {
            if (this.scrollyObserver) this.scrollyObserver.disconnect();
            
            const left = document.getElementById('ds-left-pane');
            const right = document.getElementById('ds-right-pane');
            const wrapper = document.getElementById('ds-scale-wrapper');

            // Restore Nodes
            if (this.originalNodes.length > 0) {
                this.originalNodes.forEach(n => {
                    if(n.style) n.style.transform = '';
                    document.body.appendChild(n);
                });
            } else if (wrapper) {
                 // Fallback if originalNodes empty
                 while(wrapper.firstChild) document.body.appendChild(wrapper.firstChild);
            }

            if(left) left.remove();
            if(right) right.remove();
            document.body.classList.remove('ds-scrolly-active');

            // Clean Highlights
            document.querySelectorAll('.ds-dim, .ds-highlight').forEach(el => { el.classList.remove('ds-dim'); el.classList.remove('ds-highlight'); });
        },

        // ==========================================
        // EXPLORE LOGIC
        // ==========================================
        initExplore: function() {
            const steps = Utils.generalizeLLMData(RAW_STEPS);
            
            // Build Inspector
            const container = document.createElement('div');
            container.id = 'ds-inspector';
            container.className = 'visible';
            container.innerHTML = `<div class="ds-header"><h2>Inspector Mode</h2></div><div class="ds-content" id="ds-content-area"></div>`;
            document.body.appendChild(container);

            const contentArea = document.getElementById('ds-content-area');
            const overviewStep = steps.find(s => s.step_id === 'General_Overview') || steps[0];

            function render(step) {
                contentArea.innerHTML = `
                    <div class="ds-title">${step.title}</div>
                    <div class="ds-section"><div class="ds-section-label">👀 Encoding</div><div class="ds-section-text">${step.content.encoding}</div></div>
                    <div class="ds-section"><div class="ds-section-label">💡 Insight</div><div class="ds-section-text">${step.content.insight}</div></div>
                    <div class="ds-section"><div class="ds-section-label">🖱️ Interaction</div><div class="ds-section-text">${step.content.interaction}</div></div>
                `;
            }
            render(overviewStep);

            // Handler
            this.exploreHandler = (e) => {
                if (e.target.closest('#ds-inspector') || e.target.closest('#ds-toggle-bar')) return;
                
                let match = null;
                for (let step of steps) {
                    if (step.selector && e.target.closest(step.selector)) {
                        match = step;
                        break;
                    }
                }

                document.querySelectorAll('.ds-highlight-ring').forEach(el => el.classList.remove('ds-highlight-ring'));

                if (match) {
                    render(match);
                    const actualEl = e.target.closest(match.selector);
                    if (actualEl) actualEl.classList.add('ds-highlight-ring');
                } else {
                    render(overviewStep);
                }
            };
            document.body.addEventListener('mousemove', this.exploreHandler);
        },

        teardownExplore: function() {
            const insp = document.getElementById('ds-inspector');
            if (insp) insp.remove();
            if (this.exploreHandler) document.body.removeEventListener('mousemove', this.exploreHandler);
            document.querySelectorAll('.ds-highlight-ring').forEach(el => el.classList.remove('ds-highlight-ring'));
        }
    };

    OnboardingManager.init();
})();