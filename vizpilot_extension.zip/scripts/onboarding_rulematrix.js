(function() {
    // ==========================================
    // 1. DATA (Timeline Matrix Data)
    // ==========================================
    const RAW_STEPS = [{'step_id': 'step_1',
  'text': 'Each row is a rule; columns are features; right panels summarise prediction, fidelity, and evidence.',
  'target_view': 'multiple',
  'target_category': 'view',
  'targets': {},
  'actions': ['highlight'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_2',
  'text': 'Left bars and curved connectors summarise Negative and Positive samples flowing into each rule.',
  'target_view': 'left_flows_panel',
  'target_category': 'view',
  'targets': {'view': {'candidates': [{'selector': 'g.rule-matrix g.flows',
      'confidence': 'high',
      'reason': 'Dedicated container for left-side reserves and flow curves'}]}},
  'actions': ['highlight'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_3',
  'text': 'Features include Glucose, Body Mass Index, Age, Diabetes Pedigree, Insulin, and Pregnancies.',
  'target_view': 'feature_headers',
  'target_category': 'encoding',
  'targets': {'encoding': {'candidates': [{'selector': 'g.headers g.header text.header-text',
      'confidence': 'high',
      'reason': 'Rotated feature name labels above columns'}]}},
  'actions': ['highlight', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_4',
  'text': 'Two classes are shown: Negative (blue) and Positive (orange).',
  'target_view': 'legend_labels',
  'target_category': 'encoding',
  'targets': {'encoding': {'candidates': [{'selector': 'g.rm-labels g.rm-label rect',
      'confidence': 'high',
      'reason': 'Legend color swatches for classes'},
     {'selector': 'g.rm-labels g.rm-predict rect',
      'confidence': 'high',
      'reason': 'Legend swatches using stripe patterns indicating wrong predictions'},
     {'selector': 'g.rm-labels text',
      'confidence': 'medium',
      'reason': 'Legend text labels naming categories'}]}},
  'actions': ['highlight', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_5',
  'text': 'The Glucose axis above shows numeric tick values for interpreting histogram positions.',
  'target_view': 'header_axis',
  'target_category': 'encoding',
  'targets': {'encoding': {'candidates': [{'selector': 'g.headers',
      'confidence': 'high',
      'reason': 'Tick labels encoding numeric axis values'},
     {'selector': 'g.headers g.header-axis path.domain',
      'confidence': 'medium',
      'reason': 'Axis domain line for the numeric scale'},
     {'selector': 'g.headers g.header-axis g.tick line',
      'confidence': 'medium',
      'reason': 'Tick marks on the axis'}]}},
  'actions': ['highlight', 'glow', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_6',
  'text': 'Blue and orange histograms show class distributions; the gray band marks the rule’s selected range.',
  'target_view': 'rule_matrix',
  'target_category': 'encoding',
  'targets': {'encoding': {'candidates': [{'selector': 'g.rules g.hp-hists rect',
      'confidence': 'high',
      'reason': 'Histogram bars (blue/orange) encoding class distributions per feature cell'},
     {'selector': 'g.rules rect.hp-brush',
      'confidence': 'high',
      'reason': 'Shaded selection band encoding the rule’s selected range'}]}},
  'actions': ['highlight', 'glow', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_7',
  'text': 'Each rule’s probability appears as a number with a tiny stacked bar showing class share.',
  'target_view': 'outputs_probability_panel',
  'target_category': 'encoding',
  'targets': {'encoding': {'candidates': [{'selector': 'g.outputs g.matrix-outputs text.mo-output',
      'confidence': 'high',
      'reason': 'Numeric probability text per rule'},
     {'selector': 'g.outputs g.matrix-outputs g.mo-outputs rect',
      'confidence': 'high',
      'reason': 'Tiny stacked bar encoding class shares'}]}},
  'actions': ['highlight', 'glow', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_8',
  'text': 'A green circular gauge displays fidelity, with higher numbers indicating better agreement.',
  'target_view': 'fidelity_gauge_panel',
  'target_category': 'encoding',
  'targets': {'encoding': {'candidates': [{'selector': 'g.outputs g.matrix-outputs g.mo-fidelity path.mo-fidelity',
      'confidence': 'high',
      'reason': 'Circular gauge arc encoding fidelity score'},
     {'selector': 'g.outputs g.matrix-outputs g.mo-fidelity text.mo-fidelity',
      'confidence': 'medium',
      'reason': 'Text label encoding the fidelity value'}]}},
  'actions': ['highlight', 'glow', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_9',
  'text': 'Horizontal bars show supporting instances by class; hatched segments indicate wrong predictions.',
  'target_view': 'evidence_support_panel',
  'target_category': 'encoding',
  'targets': {'encoding': {'candidates': [{'selector': 'g.outputs g.matrix-outputs g.mo-supports g.mo-support-mat rect',
      'confidence': 'high',
      'reason': 'Horizontal bars and hatched segments encoding support and errors by class'}]}},
  'actions': ['highlight', 'glow', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_10',
  'text': 'Check histograms and ranges to see which class dominates within each rule.',
  'target_view': 'rule_matrix',
  'target_category': 'encoding',
  'targets': {'encoding': {'candidates': [{'selector': 'g.rules g.hp-hists rect',
      'confidence': 'high',
      'reason': 'Histogram bars (blue/orange) encoding class distributions per feature cell'},
     {'selector': 'g.rules rect.hp-brush',
      'confidence': 'high',
      'reason': 'Shaded selection band encoding the rule’s selected range'}]}},
  'actions': ['highlight', 'trace', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_11',
  'text': 'Compare probability, fidelity, and evidence to prioritize trustworthy, well-supported rules.',
  'target_view': 'multiple',
  'target_category': 'encoding',
  'targets': {},
  'actions': ['highlight', 'trace', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_12',
  'text': 'Click a condition cell to expand a detailed stream view for that feature.',
  'target_view': 'rule_matrix',
  'target_category': 'interaction',
  'targets': {'interaction': {'candidates': [{'selector': 'g.rules g.matrix-condition',
      'confidence': 'high',
      'reason': 'Clickable condition cells for expanding detailed views'},
     {'selector': 'g.rules g.matrix-rule',
      'confidence': 'medium',
      'reason': 'Row grouping used as hover region for tooltips'},
     {'selector': 'g.rule-matrix g.cursor-follow .rm-tooltip',
      'confidence': 'medium',
      'reason': 'Tooltip element shown on hover over conditions or rows'}]}},
  'actions': ['highlight', 'pulse', 'tooltip', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_13',
  'text': 'Hover a condition or row to see its rule text tooltip.',
  'target_view': 'rule_matrix',
  'target_category': 'interaction',
  'targets': {'interaction': {'candidates': [{'selector': 'g.rules g.matrix-condition',
      'confidence': 'high',
      'reason': 'Clickable condition cells for expanding detailed views'},
     {'selector': 'g.rules g.matrix-rule',
      'confidence': 'medium',
      'reason': 'Row grouping used as hover region for tooltips'},
     {'selector': 'g.rule-matrix g.cursor-follow .rm-tooltip',
      'confidence': 'medium',
      'reason': 'Tooltip element shown on hover over conditions or rows'}]}},
  'actions': ['highlight', 'pulse', 'tooltip', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_14',
  'text': 'Use Collapse All to close every expanded row at once.',
  'target_view': 'collapse_all_button',
  'target_category': 'interaction',
  'targets': {'interaction': {'candidates': [{'selector': 'g.buttons g.reset-button',
      'confidence': 'high',
      'reason': "Clickable control labeled 'Collapse All'"}]}},
  'actions': ['highlight', 'pulse', 'tooltip', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}}];

    // ==========================================
    // 2. HELPER: UTILS (Your Generalization Logic)
    // ==========================================
    const Utils = {
        resolveSelector: (targets) => {
            if (!targets) return null;
            const priorities = ['view', 'encoding', 'interaction'];
            for (let type of priorities) {
                if (targets[type]?.candidates?.[0]?.selector) {
                    return targets[type].candidates[0].selector;
                }
            }
            return null;
        },
        generalizeLLMData: (rawSteps) => {
            const mergedData = new Map();
            const generateTitle = (candidate, defaultId) => {
                if (!candidate || !candidate.reason) return "Component: " + defaultId;
                let text = candidate.reason.toLowerCase().replace(/^(container for|wrapper of|main view of|view of|the)\s+/, '').split(' and ')[0];
                return text.replace(/\b\w/g, l => l.toUpperCase());
            };
            const categorizeText = (fullText) => {
                const sentences = fullText.match(/[^.?!]+[.?!]+|[^.?!]+$/g) || [];
                let buckets = { encoding: [], insight: [], interaction: [] };
                sentences.forEach(s => {
                    const l = s.toLowerCase().trim();
                    if (!l) return;
                    if (l.match(/(hover|click|drag|press|scroll|tooltip|select|toggle)/)) buckets.interaction.push(s.trim());
                    else if (l.match(/(look for|spot|compare|notice|reveal|identify|check|observe|pattern)/)) buckets.insight.push(s.trim());
                    else buckets.encoding.push(s.trim());
                });
                return {
                    encoding: buckets.encoding.join(' ') || "Visual encoding details.",
                    insight: buckets.insight.join(' ') || "Observe the data patterns displayed here.",
                    interaction: buckets.interaction.join(' ') || "Hover or click to interact."
                };
            };
            rawSteps.forEach(step => {
                let mainCandidate = step.targets?.view?.candidates?.[0] || step.targets?.encoding?.candidates?.[0];
                let key = mainCandidate ? mainCandidate.selector : 'General_Overview';
                if (!mergedData.has(key)) {
                    mergedData.set(key, { step_id: key, title: key === 'General_Overview' ? 'Dashboard Overview' : generateTitle(mainCandidate, step.step_id), rawText: '', targets: step.targets, selector: key });
                }
                mergedData.get(key).rawText += ' ' + step.text;
            });
            return Array.from(mergedData.values()).map(entry => ({ step_id: entry.step_id, title: entry.title, content: categorizeText(entry.rawText), targets: entry.targets, selector: entry.selector }));
        }
    };

    // ==========================================
    // 3. THE MANAGER (Controls the Toggle Flow)
    // ==========================================
    const OnboardingManager = {
        mode: 'none', // 'none', 'scrolly', 'explore'
        originalNodes: [], // Stores nodes to restore
        scrollyObserver: null,
        exploreHandler: null,
        
        init: function() {
            // --- A. Styles ---
            const style = document.createElement('style');
            style.id = 'ds-unified-style';
            style.textContent = `
                /* Top Toggle Bar */
                #ds-toggle-bar {
                    position: fixed; top: 20px; left: 50%; transform: translateX(-50%);
                    display: flex; background: #2c3e50; padding: 5px; border-radius: 30px;
                    box-shadow: 0 4px 15px rgba(0,0,0,0.3); z-index: 100000;
                }
                .ds-toggle-btn {
                    padding: 10px 20px; border: none; background: transparent; color: #bdc3c7;
                    font-family: sans-serif; font-weight: bold; font-size: 14px; cursor: pointer;
                    border-radius: 25px; transition: all 0.3s; outline: none;
                }
                .ds-toggle-btn.active { background: #3498db; color: white; box-shadow: 0 2px 10px rgba(0,0,0,0.2); }
                .ds-toggle-btn:hover:not(.active) { color: white; }

                /* Scrolly Styles */
                body.ds-scrolly-active { overflow: hidden; }
                #ds-left-pane { position: fixed; top: 0; left: 0; width: calc(100% - 300px); height: 100vh; overflow: auto; background: white; z-index: 9000; }
                #ds-right-pane { position: fixed; top: 0; right: 0; width: 300px; height: 100vh; overflow-y: scroll; background: #fcfcfc; border-left: 1px solid #eee; z-index: 9001; }
                #ds-scale-wrapper { transform-origin: top left; transition: transform 0.3s ease; padding: 20px; }
                .ds-step-container { min-height: 80vh; display: flex; align-items: center; padding: 20px; }
                .ds-step-content { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); opacity: 0.4; transition: all 0.3s; border-left: 4px solid transparent; }
                .ds-step-content.active { opacity: 1; border-left: 5px solid #9b59b6; transform: scale(1.02); }
                .ds-step-badge { background: #9b59b6; color: white; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: bold; text-transform: uppercase; margin-bottom: 8px; display: inline-block; }
                .ds-dim { opacity: 0.8 !important; transition: opacity 0.5s; }
                .ds-highlight { opacity: 1 !important; stroke: #9b59b6 !important; filter: none !important; }
                g.ds-highlight *, .ds-highlight * { opacity: 1 !important; fill-opacity: 1; stroke: #9b59b6 !important; }

                /* Inspector Styles */
                #ds-inspector { position: fixed; top: 100px; right: 20px; width: 300px; bottom: 20px; background: #1e1e1e; color: #d4d4d4; z-index: 10000; font-family: 'Segoe UI', sans-serif; box-shadow: 0 5px 25px rgba(0,0,0,0.3); border-radius: 8px; display: flex; flex-direction: column; opacity: 0; pointer-events: none; transition: opacity 0.3s; }
                #ds-inspector.visible { opacity: 1; pointer-events: auto; }
                .ds-header { padding: 15px 20px; background: #252526; border-bottom: 1px solid #333; border-radius: 8px 8px 0 0; }
                .ds-header h2 { margin: 0; font-size: 13px; text-transform: uppercase; color: #aaa; }
                .ds-content { padding: 20px; overflow-y: auto; flex: 1; }
                .ds-title { font-size: 18px; color: #fff; margin: 0 0 20px 0; font-weight: 600; border-bottom: 1px solid #333; padding-bottom: 10px; }
                .ds-section { margin-bottom: 24px; }
                .ds-section-label { color: #569cd6; font-size: 11px; font-weight: 700; text-transform: uppercase; margin-bottom: 8px; }
                .ds-section-text { font-size: 13.5px; line-height: 1.6; color: #cccccc; }
                .ds-highlight-ring { outline: 2px solid #569cd6; outline-offset: 3px; }
            `;
            document.head.appendChild(style);

            // --- B. Render Top Toggle ---
            const toggleBar = document.createElement('div');
            toggleBar.id = 'ds-toggle-bar';
            toggleBar.innerHTML = `
                <button class="ds-toggle-btn" id="ds-btn-scrolly">Guided Tour</button>
                <button class="ds-toggle-btn" id="ds-btn-explore">Free Exploration</button>
            `;
            document.body.appendChild(toggleBar);

            // --- C. Bind Events ---
            document.getElementById('ds-btn-scrolly').onclick = () => this.setMode('scrolly');
            document.getElementById('ds-btn-explore').onclick = () => this.setMode('explore');
        },

        setMode: function(newMode) {
            // If clicking the same mode, toggle it off (optional, here we just return)
            if (this.mode === newMode) return; 

            // 1. Teardown Current Mode
            if (this.mode === 'scrolly') this.teardownScrolly();
            if (this.mode === 'explore') this.teardownExplore();

            // 2. Update Buttons
            document.querySelectorAll('.ds-toggle-btn').forEach(b => b.classList.remove('active'));
            if (newMode === 'scrolly') document.getElementById('ds-btn-scrolly').classList.add('active');
            if (newMode === 'explore') document.getElementById('ds-btn-explore').classList.add('active');

            // 3. Init New Mode
            this.mode = newMode;
            if (newMode === 'scrolly') this.initScrolly();
            if (newMode === 'explore') this.initExplore();
        },

        // ==========================================
        // SCROLLY LOGIC
        // ==========================================
        initScrolly: function() {
            document.body.classList.add('ds-scrolly-active');
            
            // Capture original nodes (excluding our UI)
            this.originalNodes = Array.from(document.body.children).filter(n => 
                n.id !== 'ds-unified-style' && n.id !== 'ds-toggle-bar' && n.tagName !== 'SCRIPT'
            );

            const leftPane = document.createElement('div'); leftPane.id = 'ds-left-pane';
            const scaleWrapper = document.createElement('div'); scaleWrapper.id = 'ds-scale-wrapper';
            const rightPane = document.createElement('div'); rightPane.id = 'ds-right-pane';
            
            // Move Viz into Wrapper
            this.originalNodes.forEach(n => scaleWrapper.appendChild(n));
            leftPane.appendChild(scaleWrapper);
            document.body.appendChild(leftPane);
            document.body.appendChild(rightPane);

            // Render Steps
            RAW_STEPS.forEach((step, i) => {
                const div = document.createElement('div');
                div.className = 'ds-step-container';
                div.dataset.index = i;
                div.innerHTML = `<div class="ds-step-content"><div class="ds-step-badge">Step ${i+1}</div><div>${step.text}</div></div>`;
                rightPane.appendChild(div);
            });

            // Extra padding at bottom
            const endPad = document.createElement('div');
            endPad.style.height = "50vh";
            rightPane.appendChild(endPad);

            // Scaling
            const fitContent = () => {
                const svg = document.querySelector('svg');
                if(!svg) return;
                scaleWrapper.style.transform = 'scale(1)';
                const scale = Math.min(leftPane.offsetWidth / scaleWrapper.scrollWidth, leftPane.offsetHeight / scaleWrapper.scrollHeight) * 1.80;
                scaleWrapper.style.transform = `scale(${scale})`;
            };
            setTimeout(fitContent, 100);
            window.addEventListener('resize', fitContent);

            // Observer
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        document.querySelectorAll('.ds-step-content').forEach(c => c.classList.remove('active'));
                        entry.target.querySelector('.ds-step-content').classList.add('active');
                        
                        const index = entry.target.dataset.index;
                        const step = RAW_STEPS[index];
                        const svg = document.querySelector('svg');
                        
                        // Reset
                        svg.querySelectorAll('*').forEach(el => { el.classList.remove('ds-dim'); el.classList.remove('ds-highlight'); });

                        if (step.actions.includes('highlight')) {
                            svg.querySelectorAll('g, rect, path, circle, text, line').forEach(el => el.classList.add('ds-dim'));
                            const selector = Utils.resolveSelector(step.targets);
                            if (selector) {
                                svg.querySelectorAll(selector).forEach(el => {
                                    el.classList.remove('ds-dim'); el.classList.add('ds-highlight');
                                    let p = el.parentNode;
                                    while(p && p !== svg) { p.classList.remove('ds-dim'); p = p.parentNode; }
                                });
                            }
                        }
                    }
                });
            }, { root: rightPane, threshold: 0.6 });

            document.querySelectorAll('.ds-step-container').forEach(el => observer.observe(el));
            this.scrollyObserver = observer;
        },

        teardownScrolly: function() {
            if (this.scrollyObserver) this.scrollyObserver.disconnect();
            
            const left = document.getElementById('ds-left-pane');
            const right = document.getElementById('ds-right-pane');
            const wrapper = document.getElementById('ds-scale-wrapper');

            // Restore Nodes
            if (this.originalNodes.length > 0) {
                this.originalNodes.forEach(n => {
                    if(n.style) n.style.transform = '';
                    document.body.appendChild(n);
                });
            } else if (wrapper) {
                 // Fallback if originalNodes empty
                 while(wrapper.firstChild) document.body.appendChild(wrapper.firstChild);
            }

            if(left) left.remove();
            if(right) right.remove();
            document.body.classList.remove('ds-scrolly-active');

            // Clean Highlights
            document.querySelectorAll('.ds-dim, .ds-highlight').forEach(el => { el.classList.remove('ds-dim'); el.classList.remove('ds-highlight'); });
        },

        // ==========================================
        // EXPLORE LOGIC
        // ==========================================
        initExplore: function() {
            const steps = Utils.generalizeLLMData(RAW_STEPS);
            
            // Build Inspector
            const container = document.createElement('div');
            container.id = 'ds-inspector';
            container.className = 'visible';
            container.innerHTML = `<div class="ds-header"><h2>Inspector Mode</h2></div><div class="ds-content" id="ds-content-area"></div>`;
            document.body.appendChild(container);

            const contentArea = document.getElementById('ds-content-area');
            const overviewStep = steps.find(s => s.step_id === 'General_Overview') || steps[0];

            function render(step) {
                contentArea.innerHTML = `
                    <div class="ds-title">${step.title}</div>
                    <div class="ds-section"><div class="ds-section-label">👀 Encoding</div><div class="ds-section-text">${step.content.encoding}</div></div>
                    <div class="ds-section"><div class="ds-section-label">💡 Insight</div><div class="ds-section-text">${step.content.insight}</div></div>
                    <div class="ds-section"><div class="ds-section-label">🖱️ Interaction</div><div class="ds-section-text">${step.content.interaction}</div></div>
                `;
            }
            render(overviewStep);

            // Handler
            this.exploreHandler = (e) => {
                if (e.target.closest('#ds-inspector') || e.target.closest('#ds-toggle-bar')) return;
                
                let match = null;
                for (let step of steps) {
                    if (step.selector && e.target.closest(step.selector)) {
                        match = step;
                        break;
                    }
                }

                document.querySelectorAll('.ds-highlight-ring').forEach(el => el.classList.remove('ds-highlight-ring'));

                if (match) {
                    render(match);
                    const actualEl = e.target.closest(match.selector);
                    if (actualEl) actualEl.classList.add('ds-highlight-ring');
                } else {
                    render(overviewStep);
                }
            };
            document.body.addEventListener('mousemove', this.exploreHandler);
        },

        teardownExplore: function() {
            const insp = document.getElementById('ds-inspector');
            if (insp) insp.remove();
            if (this.exploreHandler) document.body.removeEventListener('mousemove', this.exploreHandler);
            document.querySelectorAll('.ds-highlight-ring').forEach(el => el.classList.remove('ds-highlight-ring'));
        }
    };

    OnboardingManager.init();
})();