(function() {
    let RAW_STEPS = [{'step_id': 'step_1',
  'text': 'This display is organized as a timeline matrix: a summary timeline sits at the top, a matrix of rows by date fills the center, and small row labels with mini‑summaries appear on the left. All views share the same date axis.',
  'targets': [],
  'actions': ['highlight-multiple'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_2',
  'text': 'Read time from left to right along the labeled dates (for example 2015‑04‑18, 2015‑05‑03, 2015‑05‑18, 2015‑06‑08, 2015‑07‑17). These tick marks position both the overview bars and every matrix cell.',
  'targets': {'view': {'candidates': [{'selector': 'text.timelabel',
      'confidence': 'medium',
      'reason': 'date labels positioned along the top act as axis ticks'}]},
   'encoding': {'candidates': [{'selector': 'text.timelabel',
      'confidence': 'high',
      'reason': 'text marks encoding the axis tick labels (dates)'}]},
   'interaction': {'candidates': [{'selector': 'g.high rect.high-edge',
      'confidence': 'medium',
      'reason': 'wide invisible rectangles per date likely used to capture axis interactions'}]}},
  'actions': ['highlight'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_3',
  'text': 'Each row corresponds to one entity shown by its two‑letter label (be, ca, …, ze). Each column represents a specific date. Within a row and date, the visualization records how much positive and negative activity occurred.',
  'targets': {'view': {'candidates': [{'selector': 'rect.nodeline',
      'confidence': 'high',
      'reason': 'row stripe backgrounds forming the grid'},
     {'selector': 'rect.nodeline0',
      'confidence': 'medium',
      'reason': 'left gutter grid/background cells'},
     {'selector': 'rect.nodeline1',
      'confidence': 'medium',
      'reason': 'narrow left column backgrounds'}]},
   'encoding': {'candidates': [{'selector': 'g.high rect.neg-node',
      'confidence': 'high',
      'reason': 'blue matrix marks for negative counts per row/date'},
     {'selector': 'g.high rect.pos-node',
      'confidence': 'high',
      'reason': 'red matrix marks for positive counts per row/date'}]},
   'interaction': {'candidates': [{'selector': 'g.high rect.high-edge',
      'confidence': 'high',
      'reason': 'per-date transparent layers for hover/selection across the matrix'}]}},
  'actions': ['highlight', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_4',
  'text': 'The stacked bars at the top aggregate activity across all rows for each date, letting you spot overall peaks before looking into individual rows.',
  'targets': {'view': {'candidates': [{'selector': "rect.staT[y='10']",
      'confidence': 'high',
      'reason': 'background rectangle defining the overview timeline area'},
     {'selector': 'g.staT',
      'confidence': 'medium',
      'reason': 'group(s) that contain the timeline bars'}]},
   'encoding': {'candidates': [{'selector': 'g.staT rect.staT',
      'confidence': 'high',
      'reason': 'stacked small rectangles encoding positive/negative counts in the overview'}]},
   'interaction': {'candidates': [{'selector': 'g.high rect.high-edge',
      'confidence': 'medium',
      'reason': 'per-date transparent edges used for hover/selection along the timeline and grid'}]}},
  'actions': ['highlight', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_5',
  'text': 'Color encodes polarity: red shows positive values and blue shows negative values. This color meaning is consistent across the overview bars, matrix cells, and the overlay bands.',
  'targets': {'view': {'candidates': []},
   'encoding': {'candidates': []},
   'interaction': {'candidates': []}},
  'actions': ['highlight', 'glow', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_6',
  'text': 'In the matrix, the presence and height of tiny red or blue bars in a cell indicate the amount of positive or negative activity for that row on that date. Empty cells indicate no activity recorded.',
  'targets': {'view': {'candidates': [{'selector': 'rect.nodeline',
      'confidence': 'high',
      'reason': 'row stripe backgrounds forming the grid'},
     {'selector': 'rect.nodeline0',
      'confidence': 'medium',
      'reason': 'left gutter grid/background cells'},
     {'selector': 'rect.nodeline1',
      'confidence': 'medium',
      'reason': 'narrow left column backgrounds'}]},
   'encoding': {'candidates': [{'selector': 'g.high rect.neg-node',
      'confidence': 'high',
      'reason': 'blue matrix marks for negative counts per row/date'},
     {'selector': 'g.high rect.pos-node',
      'confidence': 'high',
      'reason': 'red matrix marks for positive counts per row/date'}]},
   'interaction': {'candidates': [{'selector': 'g.high rect.high-edge',
      'confidence': 'high',
      'reason': 'per-date transparent layers for hover/selection across the matrix'}]}},
  'actions': ['highlight', 'glow', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_7',
  'text': 'Next to each row label, the small red/blue mini‑glyph summarizes that row’s overall distribution of positive versus negative values across the entire period.',
  'targets': {'view': {'candidates': [{'selector': 'g.industry',
      'confidence': 'high',
      'reason': 'container of left-side row labels'}]},
   'encoding': {'candidates': [{'selector': 'g.industry text.industry',
      'confidence': 'high',
      'reason': 'text labels for each row'},
     {'selector': 'g.staN path.mypath',
      'confidence': 'high',
      'reason': 'small left mini-distribution shapes per row'}]},
   'interaction': {'candidates': []}},
  'actions': ['highlight', 'glow', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_8',
  'text': 'Rounded vertical bands highlight dates when multiple rows become active together. Peach bands mark coordinated positives; blue bands mark coordinated negatives. Thin connectors link such bands across dates to show sequences.',
  'targets': {'view': {'candidates': [{'selector': 'line.kelp',
      'confidence': 'medium',
      'reason': 'lines connecting events across rows'},
     {'selector': 'path.kelp',
      'confidence': 'medium',
      'reason': 'rounded band/connector shapes'}]},
   'encoding': {'candidates': [{'selector': 'line.kelp.posline',
      'confidence': 'high',
      'reason': 'positive (red) connector lines'},
     {'selector': 'line.kelp.negline',
      'confidence': 'high',
      'reason': 'negative (blue) connector lines'},
     {'selector': 'path.kelp.kelpnp',
      'confidence': 'high',
      'reason': 'blue connector capsules/bridges'},
     {'selector': 'path.kelp.kelppp',
      'confidence': 'high',
      'reason': 'red connector capsules/bridges'}]},
   'interaction': {'candidates': []}},
  'actions': ['highlight', 'glow', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_9',
  'text': 'Use the top summary to locate major bursts. A standout surge occurs around 2015‑07‑17; inspecting the matrix at that date shows many rows lighting up together, with adjacent blue and red segments indicating a mix of negative and positive activity.',
  'targets': {'view': {'candidates': [{'selector': "rect.staT[y='10']",
      'confidence': 'high',
      'reason': 'background rectangle defining the overview timeline area'},
     {'selector': 'g.staT',
      'confidence': 'medium',
      'reason': 'group(s) that contain the timeline bars'}]},
   'encoding': {'candidates': [{'selector': 'g.staT rect.staT',
      'confidence': 'high',
      'reason': 'stacked small rectangles encoding positive/negative counts in the overview'}]},
   'interaction': {'candidates': [{'selector': 'g.high rect.high-edge',
      'confidence': 'medium',
      'reason': 'per-date transparent edges used for hover/selection along the timeline and grid'}]}},
  'actions': ['highlight', 'trace', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_10',
  'text': 'Look for columns where multiple rows show bars on the same date—these align with the pale overlay bands and reveal coordinated events. Smaller clusters also appear in late April and early May, suggesting shorter, earlier waves of activity.',
  'targets': {'view': {'candidates': [{'selector': 'rect.nodeline',
      'confidence': 'high',
      'reason': 'row stripe backgrounds forming the grid'},
     {'selector': 'rect.nodeline0',
      'confidence': 'medium',
      'reason': 'left gutter grid/background cells'},
     {'selector': 'rect.nodeline1',
      'confidence': 'medium',
      'reason': 'narrow left column backgrounds'}]},
   'encoding': {'candidates': [{'selector': 'g.high rect.neg-node',
      'confidence': 'high',
      'reason': 'blue matrix marks for negative counts per row/date'},
     {'selector': 'g.high rect.pos-node',
      'confidence': 'high',
      'reason': 'red matrix marks for positive counts per row/date'}]},
   'interaction': {'candidates': [{'selector': 'g.high rect.high-edge',
      'confidence': 'high',
      'reason': 'per-date transparent layers for hover/selection across the matrix'}]}},
  'actions': ['highlight', 'trace', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_11',
  'text': 'Adjust Max to rescale bar heights and make small differences easier to see. Increase Threshold to hide minor bars and focus on stronger signals.',
  'targets': {'view': {'candidates': []},
   'encoding': {'candidates': []},
   'interaction': {'candidates': []}},
  'actions': ['highlight','pulse', 'tooltip', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_12',
  'text': 'Use OrderWeight and the Reorder control to change the row order; this can group rows that activate together and makes banded columns easier to compare.',
  'targets': {'view': {'candidates': []},
   'encoding': {'candidates': []},
   'interaction': {'candidates': []}},
  'actions': ['highlight', 'pulse', 'tooltip', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_13',
  'text': 'Toggle UnfoldType (Diff), FoldMatrix, and DiffMask (On/Off) to alter how the matrix emphasizes differences and whether coordinated bands or detailed cells are foregrounded.',
  'targets': {'view': {'candidates': []},
   'encoding': {'candidates': []},
   'interaction': {'candidates': []}},
  'actions': ['highlight', 'pulse', 'tooltip', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}},
 {'step_id': 'step_14',
  'text': 'Switch Mode (e.g., Degree) to change the metric used for highlighting; this affects which rows and dates are emphasized in the matrix and overlay bands.',
  'targets': {'view': {'candidates': []},
   'encoding': {'candidates': []},
   'interaction': {'candidates': []}},
  'actions': ['highlight', 'pulse', 'tooltip', 'annotation'],
  'annotation': {'type': 'callout', 'placement': 'auto'}}];

// ==========================================
// 2. THE VIS WALKTHROUGH LIBRARY
// ==========================================

    class VisWalkthrough {
        constructor(config) {
            this.steps = config.steps || [];
            this.theme = { primary: '#2c3e50', highlight: '#9b59b6' };
            this.mode = 'none';
            this.originalNodes = [];
            this.observer = null;
            this.handler = null;
            this.isAuthorMode = false;
            this.currentContext = null;
            this.chatHistory = [];
            this.targetSvg = null;
            this.apiKey = ''; 
        }
 
        init() {
    if(document.getElementById('vw-styles')) return;
    this._injectStyles();
    this._renderToggleBar();
 
    // NEW: Logic to find the main visualization SVG
    const allSvgs = document.querySelectorAll("svg");
    let maxScore = 0;
    allSvgs.forEach(s => {
        const rect = s.getBoundingClientRect();
        const score = s.querySelectorAll("*").length + rect.width;
        // Looking for the SVG with the most elements (the chart)
        if (rect.width > 200 && score > maxScore) { 
            maxScore = score; 
            this.targetSvg = s; 
        }
    });
}
 
        setMode(newMode) {
            if (this.mode === newMode) return;
            if (this.mode === 'edit') this._saveFromDOM();
            this._teardown();
            this.mode = newMode;
            
            document.querySelectorAll('.vw-toggle-btn').forEach(b => b.classList.remove('active'));
            const btn = document.getElementById(`vw-btn-${newMode}`);
            if(btn) btn.classList.add('active');
 
            if (newMode === 'scrolly') this._initScrolly();
            else if (newMode === 'explore') this._initExplore();
            else if (newMode === 'edit') this._initEditMode();
        }
 
        _makeDraggable(el, handle) {
            let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
            handle.onmousedown = (e) => {
                e.preventDefault();
                pos3 = e.clientX; pos4 = e.clientY;
                document.onmouseup = () => { document.onmouseup = null; document.onmousemove = null; };
                document.onmousemove = (e) => {
                    e.preventDefault();
                    pos1 = pos3 - e.clientX; pos2 = pos4 - e.clientY;
                    pos3 = e.clientX; pos4 = e.clientY;
                    el.style.top = (el.offsetTop - pos2) + "px";
                    el.style.left = (el.offsetLeft - pos1) + "px";
                    el.style.bottom = 'auto';
                };
            };
        }
 
    // --- EXPLORE LOGIC ---
    _initExplore() {
    const steps = this._generalizeData(this.steps);
    let insp = document.getElementById('vw-inspector');
    
    if(!insp) {
        insp = document.createElement('div');
        insp.id = 'vw-inspector';
        insp.innerHTML = `
            <div id="vw-insp-drag">
                <div class="vw-drag-handle">Inspector</div>
                <button id="vw-insp-close" title="Close">✕</button>
            </div>
            <div class="vw-insp-scroll-area">
                <div class="vw-insp-body-wrap" id="vw-insp-body"></div>
            </div>
            <div class="vw-chatbot-branding">
                <div class="vw-ai-sparkle">✦</div>
                <span>Exploration Assistant</span>
            </div>
            <div class="vw-chat-container">
                <div class="vw-chat-messages" id="vw-chat-history">
                    <div class="vw-msg bot">Hi. What would you like to know about this visualization?</div>
                </div>
                <div class="vw-chat-input-area">
                    <input type="text" id="vw-chat-input" placeholder="Ask about this visualization…" autocomplete="off">
                    <button id="vw-chat-send" title="Send">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="22" y1="2" x2="11" y2="13"></line>
                            <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                        </svg>
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(insp);
        this._makeDraggable(insp, document.getElementById('vw-insp-drag'));
        document.getElementById('vw-insp-close').onclick = () => insp.classList.remove('visible');
    }
 
    const input = document.getElementById('vw-chat-input');
    const sendBtn = document.getElementById('vw-chat-send');
    
    const sendMsg = async () => {
        const txt = input.value.trim();
        if(!txt) return;
        this._addChatMessage('user', txt);
        input.value = '';
        const historyDiv = document.getElementById('vw-chat-history');
        const loadingId = 'loading-' + Date.now();
        const loadingMsg = document.createElement('div');
        loadingMsg.className = 'vw-msg bot';
        loadingMsg.id = loadingId;
        loadingMsg.innerHTML = '<span style="opacity:0.6;font-style:italic;">Thinking…</span>';
        historyDiv.appendChild(loadingMsg);
        historyDiv.scrollTop = historyDiv.scrollHeight;
        try {
            const response = await this._fetchChatGPTResponse(txt);
            document.getElementById(loadingId).remove();
            this._addChatMessage('bot', response);
        } catch (error) {
            if(document.getElementById(loadingId)) document.getElementById(loadingId).remove();
            this._addChatMessage('bot', "Error: Check your API Key or Console.");
            console.error(error);
        }
    };
 
    sendBtn.onclick = (e) => { e.preventDefault(); sendMsg(); };
    input.onkeydown = (e) => { if(e.key === 'Enter') { e.preventDefault(); sendMsg(); } };
 
    setTimeout(() => insp.classList.add('visible'), 50);
 
    const render = (s) => {
        this.currentContext = s; 
        const body = document.getElementById('vw-insp-body');
        if(body) {
            body.innerHTML = `
                <div class="vw-insp-title">${s.title}</div>
                <details open class="vw-collapsible-sect">
                    <summary><span class="vw-sect-icon">📐</span> Purpose & Encoding</summary>
                    <div class="vw-insp-txt">${s.content.encoding}</div>
                </details>
                <details open class="vw-collapsible-sect">
                    <summary><span class="vw-sect-icon">🔍</span> What to look for</summary>
                    <div class="vw-insp-txt">${s.content.insight}</div>
                </details>
                <details open class="vw-collapsible-sect">
                    <summary><span class="vw-sect-icon">🖱️</span> How to interact</summary>
                    <div class="vw-insp-txt">${s.content.interaction}</div>
                </details>
            `;
        }
    };
 
    const overview = steps.find(s => s.step_id === 'General_Overview') || steps[0];
    render(overview);
 
    this.exploreHandler = (e) => {
        if (e.target.closest('#vw-inspector') || e.target.closest('#vw-toggle-bar')) return;
        let match = null;
        for (let step of steps) {
            if (step.selector !== 'General_Overview' && (e.target.matches(step.selector) || e.target.closest(step.selector))) {
                match = step; break;
            }
        }
        document.querySelectorAll('.vw-ring').forEach(el => el.classList.remove('vw-ring'));
        if (match) {
            render(match);
            const el = e.target.closest(match.selector) || e.target;
            el.classList.add('vw-ring');
        } else {
            render(overview);
        }
    };
 
    document.body.addEventListener('mouseover', this.exploreHandler);
    }
 
    _addChatMessage(role, text) {
        const history = document.getElementById('vw-chat-history');
        const msg = document.createElement('div');
        msg.className = `vw-msg ${role}`;
        msg.innerText = text;
        history.appendChild(msg);
        history.scrollTop = history.scrollHeight;
    }
    async _fetchChatGPTResponse(txt) {
  const bitmapUrl = await this._getSVGBitmap();

  const contextData = JSON.stringify(
    this.steps.map(s => ({
      component: s.step_id,
      description: s.text,
      visual_targets: s.targets
    }))
  );

  const currentFocus = this.currentContext
    ? this.currentContext.title
    : 'the general overview';

  const currentDetails = this.currentContext
    ? JSON.stringify(this.currentContext.content)
    : '';

  // Build the user message (text + optional image)
  let userContent = [{ type: 'text', text: txt }];
  if (bitmapUrl) {
    userContent.push({
      type: 'image_url',
      image_url: { url: bitmapUrl, detail: 'low' }
    });
  }

  // ✅ Call YOUR backend — no API key in extension
  const res = await fetch('https://vizpilot-backend.onrender.com/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      messages: [
        {
          role: 'system',
          content: `You are an expert data visualization assistant.
Reference data: ${contextData}
User is viewing: ${currentFocus}.
Details: ${currentDetails}
Answer strictly based on reference data. Keep answers under 50 words.`
        },
        { role: 'user', content: userContent }
      ]
    })
  });

  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data.reply;
}
    // --- STYLES ---
    _injectStyles() {
        const style = document.createElement('style');
        style.id = 'vw-styles';
        style.textContent = `
            @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600&family=DM+Mono:wght@400;500;600&display=swap');
 
            /* ── Toggle Bar ── */
            #vw-toggle-bar {
  position: fixed;
  top: 12px;
  right: 16px;
  display: inline-flex; /* Use inline-flex so it only takes up needed space */
  width: auto;         /* Prevent it from stretching across the screen */
  align-items: center;
  gap: 4px;
  background: rgba(255,255,255,0.96);
  border: 0.5px solid rgba(0,0,0,0.12);
  border-radius: 12px;
  padding: 4px 5px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  z-index: 2147483647;
  pointer-events: all; /* Ensure buttons are clickable... */
}

 
            .vw-toggle-btn {
                padding: 7px 14px; border: none; background: transparent;
                color: #555; font-weight: 500; font-size: 12.5px;
                cursor: pointer; border-radius: 30px;
                transition: background 0.15s, color 0.15s;
                display: flex; align-items: center; gap: 6px; outline: none;
                font-family: 'DM Sans', sans-serif;
            }
 
            .vw-toggle-btn:hover:not(.active) { background: rgba(0,0,0,0.05); color: #222; }
 
            .vw-toggle-btn.active {
                background: #111; color: #fff; font-weight: 500;
                box-shadow: 0 1px 3px rgba(0,0,0,0.2);
            }
 
            .vw-toggle-divider { width: 0.5px; height: 18px; background: rgba(0,0,0,0.1); margin: 0 2px; flex-shrink: 0; }
 
            .vw-audio-btn {
                width: 30px; height: 30px; border: none; background: transparent;
                border-radius: 7px; display: flex; align-items: center; justify-content: center;
                cursor: pointer; font-size: 13px; color: #666;
                transition: background 0.15s, color 0.15s;
            }
            .vw-audio-btn:hover { background: rgba(0,0,0,0.05); color: #222; }
 
            /* ── Scrolly layout ── */
            body.vw-scrolly-active { overflow: hidden !important; }
            #vw-left  { position: fixed; left: 0; width: calc(100% - 320px); overflow: auto; background: white; z-index: 2147483640; }
            #vw-right { position: fixed; right: 0; width: 320px; overflow-y: scroll; background: #fcfcfc; border-left: 1px solid #eee; z-index: 2147483641; display: flex; flex-direction: column; }
            #vw-scale { transform-origin: top left; transition: transform 0.3s ease; padding: 20px; }
 
            /* ── Breadcrumb bar ── */
            #vw-breadcrumb { position: sticky; top: 0; z-index: 10; background: rgba(252,252,252,0.97); backdrop-filter: blur(6px); border-bottom: 1px solid #e8e8e8; padding: 10px 14px 8px; font-family: 'DM Mono', monospace; font-size: 11px; flex-shrink: 0; }
            #vw-breadcrumb .vw-bc-label { color: #999; letter-spacing: .06em; text-transform: uppercase; margin-bottom: 6px; }
            #vw-breadcrumb .vw-bc-track { display: flex; align-items: center; gap: 3px; flex-wrap: wrap; }
            .vw-bc-dot { width: 8px; height: 8px; border-radius: 50%; background: #ddd; transition: all 0.3s; cursor: default; flex-shrink: 0; }
            .vw-bc-dot.done    { background: #7fba8a; }
            .vw-bc-dot.current { background: #3b7ef5; width: 22px; border-radius: 4px; box-shadow: 0 0 0 3px rgba(59,126,245,0.2); }
            .vw-bc-dot.upcoming { background: #e0e0e0; }
            #vw-breadcrumb .vw-bc-counter { margin-top: 5px; color: #666; font-size: 12px; font-family: sans-serif; }
            #vw-breadcrumb .vw-bc-counter strong { color: #3b7ef5; }
 
            /* ── Narration pill ── */
            .vw-narration-pill {
                background: #f0f2f5; border: 1px solid #e0e4e8; color: #4a5568;
                padding: 6px 24px; border-radius: 24px; font-family: 'DM Mono', monospace;
                font-size: 10px; font-weight: 700; letter-spacing: 0.1em;
                cursor: pointer; display: flex; align-items: center; gap: 8px;
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                box-shadow: 0 2px 4px rgba(0,0,0,0.03); border: none;
            }
            .vw-narration-pill:hover { background: #fff; border: 1px solid #3b7ef5; color: #3b7ef5; transform: translateY(-1px); box-shadow: 0 4px 12px rgba(59,126,245,0.15); }
            .vw-narration-pill.active { background: #3b7ef5; border: 1px solid #3b7ef5; color: #fff; box-shadow: 0 4px 15px rgba(59,126,245,0.3); }
            .vw-narration-pill .vw-icon { font-size: 8px; }
            .vw-narration-pill.active .vw-icon { animation: vw-blink 1.5s infinite; }
            @keyframes vw-blink { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
 
            /* ── Scrolly cards ── */
            #vw-steps-scroll { flex: 1; overflow-y: scroll; padding-bottom: 40vh; }
            .vw-step { min-height: 80vh; display: flex; align-items: center; padding: 16px 14px; box-sizing: border-box; }
            .vw-card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); opacity: 0.4; transition: all 0.3s; border-left: 4px solid transparent; width: 100%; color: #333; font-family: 'DM Sans', sans-serif; font-size: 14px; line-height: 1.5; }
            .vw-card.active { opacity: 1; border-left: 5px solid #3b7ef5; transform: scale(1.02); box-shadow: 0 6px 20px rgba(59,126,245,0.15); }
 
            .vw-card-header { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; }
            .vw-step-counter { font-size: 11px; color: #aaa; font-family: 'DM Mono', monospace; letter-spacing: .04em; background: #f5f5f5; padding: 3px 8px; border-radius: 20px; }
            .vw-step-counter span { color: #3b7ef5; font-weight: 700; }
 
            .vw-step-type {
                font-family: 'DM Mono', monospace; font-size: 9px; font-weight: 600;
                letter-spacing: 0.05em; padding: 2px 8px; border-radius: 4px;
                text-transform: uppercase; border: 1px solid transparent;
            }
            .type-structure   { color: #a8a8a8; background: rgba(0,0,0,0.03); border-color: rgba(0,0,0,0.08); }
            .type-data        { color: #2ecc71; background: rgba(46,204,113,0.1); border-color: rgba(46,204,113,0.2); }
            .type-encoding    { color: #3498db; background: rgba(52,152,219,0.1); border-color: rgba(52,152,219,0.2); }
            .type-analytical  { color: #9b59b6; background: rgba(155,89,182,0.1); border-color: rgba(155,89,182,0.2); }
            .type-interaction { color: #e67e22; background: rgba(230,126,34,0.1); border-color: rgba(230,126,34,0.2); }
 
            /* ── Highlights ── */
            .vw-dim { opacity: 0.5 !important; transition: opacity 0.5s; }
            .vw-highlight { opacity: 1 !important; stroke-width: 3px !important; }
            g.vw-highlight *, .vw-highlight * { opacity: 1 !important; fill-opacity: 1; }
            .vw-ring { outline: 2px solid #569cd6; outline-offset: 3px; }
 
            /* ── Pulse ── */
            .vw-pulse { animation: vw-pulse-glow 1.5s infinite; }
            @keyframes vw-pulse-glow {
                0%   { filter: drop-shadow(0 0 2px #3498db); stroke-width: 2; }
                50%  { filter: drop-shadow(0 0 10px #3498db); stroke-width: 5; }
                100% { filter: drop-shadow(0 0 2px #3498db); stroke-width: 2; }
            }
 
            /* ── Inspector panel ── */
            #vw-inspector {
                position: fixed; top: 72px; right: 16px; width: 336px; bottom: 16px;
                background: rgba(11,12,17,0.94);
                backdrop-filter: blur(28px) saturate(180%); -webkit-backdrop-filter: blur(28px) saturate(180%);
                border: 1px solid rgba(255,255,255,0.08); border-top: 1px solid rgba(255,255,255,0.13);
                box-shadow: 0 0 0 1px rgba(0,0,0,0.5), 0 32px 72px rgba(0,0,0,0.65), inset 0 1px 0 rgba(255,255,255,0.06);
                border-radius: 18px; z-index: 2147483645; font-family: 'DM Sans', -apple-system, sans-serif;
                display: flex; flex-direction: column;
                opacity: 0; pointer-events: none;
                transition: opacity 0.35s cubic-bezier(0.16,1,0.3,1), transform 0.35s cubic-bezier(0.16,1,0.3,1);
                transform: translateX(14px) scale(0.97); overflow: hidden; color: #e2e4ea;
            }
            #vw-inspector.visible { opacity: 1; pointer-events: auto; transform: translateX(0) scale(1); }
 
            /* ── Drag Header ── */
            #vw-insp-drag {
                display: flex; align-items: center; justify-content: space-between;
                padding: 14px 16px 12px; cursor: grab; flex-shrink: 0;
                border-bottom: 1px solid rgba(255,255,255,0.06);
                background: rgba(255,255,255,0.025); user-select: none;
            }
            #vw-insp-drag:active { cursor: grabbing; }
            .vw-drag-handle {
                display: flex; align-items: center; gap: 9px;
                color: rgba(255,255,255,0.32); font-size: 10.5px;
                font-family: 'DM Mono', monospace; letter-spacing: 0.13em; text-transform: uppercase; font-weight: 500;
            }
            .vw-drag-handle::before {
                content: ''; display: block; width: 14px; height: 10px;
                background-image: radial-gradient(circle, rgba(255,255,255,0.28) 1.2px, transparent 1.2px);
                background-size: 5.5px 5.5px;
            }
            #vw-insp-close {
                width: 22px; height: 22px; border-radius: 50%;
                background: rgba(255,255,255,0.08); border: none; color: rgba(255,255,255,0.4);
                cursor: pointer; font-size: 12px; display: flex; align-items: center; justify-content: center;
                transition: background 0.15s, color 0.15s;
            }
            #vw-insp-close:hover { background: rgba(255,255,255,0.15); color: #fff; }
 
            /* ── Inspector scrollable content ── */
            .vw-insp-scroll-area {
                flex: 1; overflow-y: auto; overflow-x: hidden; display: flex; flex-direction: column;
                scrollbar-width: thin; scrollbar-color: rgba(255,255,255,0.08) transparent;
            }
            .vw-insp-scroll-area::-webkit-scrollbar { width: 3px; }
            .vw-insp-scroll-area::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.08); border-radius: 4px; }
 
            .vw-insp-body-wrap { padding: 14px 16px 4px; }
            .vw-insp-title { font-size: 15px; font-weight: 600; color: #f0f2f8; margin-bottom: 14px; line-height: 1.3; }
 
            .vw-collapsible-sect { border-top: 1px solid rgba(255,255,255,0.05); }
            .vw-collapsible-sect summary {
                padding: 9px 13px; font-size: 10.5px; font-weight: 600;
                letter-spacing: 0.06em; text-transform: uppercase;
                color: rgba(255,255,255,0.38); cursor: pointer; list-style: none;
                transition: color 0.18s; user-select: none; display: flex; align-items: center;
            }
            .vw-collapsible-sect summary::-webkit-details-marker { display: none; }
            .vw-collapsible-sect summary::after {
                content: '›'; margin-left: auto; font-size: 15px;
                color: rgba(255,255,255,0.18); transition: transform 0.2s, color 0.2s; display: inline-block;
            }
            .vw-collapsible-sect[open] summary { color: rgba(255,255,255,0.65); }
            .vw-collapsible-sect[open] summary::after { transform: rotate(90deg); color: rgba(255,255,255,0.35); }
            .vw-collapsible-sect .vw-insp-txt {
                padding: 2px 13px 13px; font-size: 12.5px; line-height: 1.68;
                color: rgba(200,208,228,0.78); font-weight: 400;
                animation: vw-sect-open 0.18s ease;
            }
            @keyframes vw-sect-open { from { opacity:0; transform:translateY(-4px); } to { opacity:1; transform:translateY(0); } }
            .vw-sect-icon { font-size: 12px; opacity: 0.65; margin-right: 6px; }
 
            /* ── AI divider ── */
            .vw-chatbot-branding {
                display: flex; align-items: center; gap: 9px;
                padding: 13px 16px 8px; flex-shrink: 0;
            }
            .vw-chatbot-branding::before { content: ''; flex: 1; height: 1px; background: linear-gradient(to right, transparent, rgba(255,255,255,0.07)); }
            .vw-chatbot-branding::after  { content: ''; flex: 0 0 30px; height: 1px; background: rgba(255,255,255,0.05); }
            .vw-chatbot-branding span { font-family: 'DM Mono', monospace; font-size: 9.5px; font-weight: 500; letter-spacing: 0.15em; text-transform: uppercase; color: rgba(255,255,255,0.22); }
            .vw-ai-sparkle { width: 20px; height: 20px; border-radius: 6px; background: linear-gradient(135deg, #3b7ef5, #8b5cf6); display: flex; align-items: center; justify-content: center; font-size: 10px; color: white; flex-shrink: 0; box-shadow: 0 2px 10px rgba(59,126,245,0.45); }
 
            /* ── Chat container ── */
            .vw-chat-container { display: flex; flex-direction: column; flex: 1; min-height: 0; border-top: 1px solid rgba(255,255,255,0.05); }
            .vw-chat-messages { flex: 1; overflow-y: auto; padding: 12px 13px; display: flex; flex-direction: column; gap: 9px; scrollbar-width: thin; scrollbar-color: rgba(255,255,255,0.07) transparent; min-height: 100px; }
            .vw-chat-messages::-webkit-scrollbar { width: 3px; }
            .vw-chat-messages::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.07); border-radius: 4px; }
 
            /* ── Message bubbles ── */
            .vw-msg { max-width: 84%; padding: 9px 13px; border-radius: 14px; font-size: 12.5px; line-height: 1.55; font-weight: 400; animation: vw-pop 0.22s cubic-bezier(0.34,1.56,0.64,1); word-break: break-word; }
            @keyframes vw-pop { from { transform: scale(0.88) translateY(4px); opacity: 0; } to { transform: scale(1) translateY(0); opacity: 1; } }
            .vw-msg.bot { background: rgba(255,255,255,0.058); color: rgba(215,222,240,0.88); align-self: flex-start; border-bottom-left-radius: 4px; border: 1px solid rgba(255,255,255,0.065); }
            .vw-msg.user { background: linear-gradient(135deg, #3067d4, #4f4fd4); color: #fff; align-self: flex-end; border-bottom-right-radius: 4px; box-shadow: 0 4px 18px rgba(59,126,245,0.32); }
 
            /* ── Chat input ── */
            .vw-chat-input-area { display: flex; align-items: center; gap: 8px; padding: 11px 13px 13px; background: rgba(0,0,0,0.18); border-top: 1px solid rgba(255,255,255,0.05); flex-shrink: 0; }
            #vw-chat-input { flex: 1; background: rgba(255,255,255,0.055); border: 1px solid rgba(255,255,255,0.1); border-radius: 22px; color: rgba(225,230,248,0.9); padding: 8px 15px; font-size: 12.5px; font-family: 'DM Sans', sans-serif; outline: none; transition: border-color 0.2s, background 0.2s, box-shadow 0.2s; caret-color: #4f8ef7; }
            #vw-chat-input::placeholder { color: rgba(255,255,255,0.18); }
            #vw-chat-input:focus { border-color: rgba(59,126,245,0.48); background: rgba(255,255,255,0.08); box-shadow: 0 0 0 3px rgba(59,126,245,0.1); }
            #vw-chat-send { width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, #3b7ef5, #5b5ef7); border: none; color: white; cursor: pointer; display: flex; align-items: center; justify-content: center; flex-shrink: 0; transition: transform 0.15s, box-shadow 0.15s, filter 0.15s; box-shadow: 0 3px 12px rgba(59,126,245,0.4); }
            #vw-chat-send:hover { transform: scale(1.1); box-shadow: 0 5px 20px rgba(59,126,245,0.58); filter: brightness(1.08); }
            #vw-chat-send:active { transform: scale(0.93); }
 
            /* ── Action btn ── */
            .vw-action-btn { width: 90%; margin: 10px auto; display: block; padding: 10px; background: #27ae60; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; }
        `;
        document.head.appendChild(style);
    }
 
    _initEditMode() {
        this._initScrolly(); 
        document.body.classList.add('vw-editing');
        document.querySelectorAll('.vw-card div:last-child').forEach(el => {
            el.contentEditable = "true";
            el.style.border = "1px dashed #ccc";
            el.style.padding = "5px";
            el.style.backgroundColor = "#fffef0";
            el.style.outline = "none";
        });
        const rightPane = document.getElementById('vw-right');
        const addBtn = document.createElement('button');
        addBtn.innerText = "+ Add New Step";
        addBtn.className = "vw-action-btn";
        addBtn.onclick = () => this._addNewStep();
        rightPane.prepend(addBtn);
    }
 
    _addNewStep() {
        const newStep = { step_id: `step_${Date.now()}`, text: "New step description...", targets: {}, actions: ['highlight'] };
        this.steps.push(newStep);
        this._teardown(); 
        this._initEditMode();
        setTimeout(() => {
            const right = document.getElementById('vw-right');
            right.scrollTop = right.scrollHeight;
        }, 100);
    }
 
    _saveFromDOM() {
        const cards = document.querySelectorAll('.vw-card');
        if (cards.length === 0) return; 
        cards.forEach((card, i) => { if (this.steps[i]) this.steps[i].text = card.lastChild.innerText; });
        console.log("✅ Changes Saved:", this.steps);
    }
 
    exportConfig() {
        if (this.mode === 'edit') this._saveFromDOM();
        const dataStr = "const RAW_STEPS = " + JSON.stringify(this.steps, null, 4) + ";";
        const blob = new Blob([dataStr], { type: "text/javascript" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url; a.download = "content.js"; 
        document.body.appendChild(a);
        a.click(); document.body.removeChild(a);
    }
 
    _teardown() {
            if (this.scrollyObserver) this.scrollyObserver.disconnect();
            const left = document.getElementById('vw-left');
            const right = document.getElementById('vw-right');
            const wrapper = document.getElementById('vw-scale');
 
            if (this.originalNodes.length > 0) {
                this.originalNodes.forEach(n => { if(n.style) n.style.transform = ''; document.body.appendChild(n); });
            } else if (wrapper) { while(wrapper.firstChild) document.body.appendChild(wrapper.firstChild); }
 
            if(left) left.remove(); if(right) right.remove();
            document.body.classList.remove('vw-scrolly-active');
 
            const insp = document.getElementById('vw-inspector');
            if (insp) insp.classList.remove('visible');
            if (this.exploreHandler) document.body.removeEventListener('mousemove', this.exploreHandler);
 
            document.querySelectorAll('.vw-dim, .vw-highlight, .vw-ring').forEach(el => {
                el.classList.remove('vw-dim', 'vw-highlight', 'vw-ring');
            });
        }
 
    _resolveSelector(targets) {
    if (!targets) return [];
    let found = [];
    
    // Look through all possible target types in your RAW_STEPS
    const categories = ['encoding', 'view', 'interaction'];
    
    categories.forEach(type => {
        if (targets[type] && targets[type].candidates) {
            targets[type].candidates.forEach(c => {
                if (c.selector) {
                    // Only add if it actually exists in the DOM to avoid errors
                    found.push(c.selector);
                }
            });
        }
    });
        // Return unique selectors
        return [...new Set(found)];
    }
 
    _initScrolly() {
            document.body.classList.add('vw-scrolly-active');
            this.originalNodes = Array.from(document.body.children).filter(n => !n.id.startsWith('vw-') && n.tagName !== 'SCRIPT' && n.tagName !== 'STYLE');
            
            const left = document.createElement('div'); left.id = 'vw-left';
            const wrapper = document.createElement('div'); wrapper.id = 'vw-scale';
            const right = document.createElement('div'); right.id = 'vw-right';
 
            const barHeight = 70;
            left.style.top = barHeight + 'px';
            left.style.height = `calc(100vh - ${barHeight}px)`;
            right.style.top = barHeight + 'px';
            right.style.height = `calc(100vh - ${barHeight}px)`;
 
            this.originalNodes.forEach(n => wrapper.appendChild(n));
            left.appendChild(wrapper); document.body.appendChild(left); document.body.appendChild(right);
 
            const total = this.steps.length;
 
            // ── Breadcrumb bar ──
            const bcBar = document.createElement('div');
            bcBar.id = 'vw-breadcrumb';
            bcBar.innerHTML = `
                <div style="display:flex;flex-direction:column;align-items:center;gap:12px;width:100%;">
                    <div style="width:100%;">
                        <div class="vw-bc-label" style="text-align:center;margin-bottom:8px;">Tour Progress</div>
                        <div class="vw-bc-track" id="vw-bc-track" style="justify-content:center;"></div>
                    </div>
                    <button id="vw-start-audio" class="vw-narration-pill">
                        <span class="vw-icon">▶</span> START NARRATION
                    </button>
                    <div class="vw-bc-counter">Step <strong id="vw-bc-num">1</strong> of <strong>${total}</strong></div>
                </div>
            `;
            right.appendChild(bcBar);
 
            // Narration pill toggle
            this.narrationStarted = false;
            this.synth = this.synth || window.speechSynthesis;
            const audioBtn = bcBar.querySelector('#vw-start-audio');
            audioBtn.onclick = () => {
                this.narrationStarted = !this.narrationStarted;
                if (this.narrationStarted) {
                    audioBtn.classList.add('active');
                    audioBtn.innerHTML = '<span class="vw-icon">■</span> STOP NARRATION';
                } else {
                    audioBtn.classList.remove('active');
                    audioBtn.innerHTML = '<span class="vw-icon">▶</span> START NARRATION';
                    if (this.synth) this.synth.cancel();
                }
            };
 
            // Build dot track
            const track = bcBar.querySelector('#vw-bc-track');
            this.steps.forEach((_, i) => {
                const dot = document.createElement('div');
                dot.className = 'vw-bc-dot ' + (i === 0 ? 'current' : 'upcoming');
                dot.id = `vw-dot-${i}`;
                track.appendChild(dot);
            });
 
            // ── Steps scroll area ──
            const stepsScroll = document.createElement('div');
            stepsScroll.id = 'vw-steps-scroll';
            right.appendChild(stepsScroll);
 
            const stepTypeMap = { structure: 'structure', data: 'data', encoding: 'encoding', analytical: 'analytical', interaction: 'interaction' };
 
            this.steps.forEach((step, i) => {
                const stepType = step.step_type || 'structure';
                const typeLabel = stepTypeMap[stepType] || 'structure';
                const div = document.createElement('div');
                div.className = 'vw-step';
                div.dataset.index = i;
                div.innerHTML = `
                    <div class="vw-card" id="vw-card-${i}">
                        <div class="vw-card-header">
                            <div class="vw-step-counter">Step <span>${i + 1}</span></div>
                            <div class="vw-step-type type-${typeLabel}">${typeLabel}</div>
                        </div>
                        <div>${step.text}</div>
                    </div>`;
                stepsScroll.appendChild(div);
            });
 
            const endPad = document.createElement('div'); endPad.style.height = '50vh'; stepsScroll.appendChild(endPad);
 
            const fit = () => {
                wrapper.style.transform = 'scale(1)';
                const scale = Math.min(left.offsetWidth / wrapper.scrollWidth, left.offsetHeight / wrapper.scrollHeight) * 0.9;
                wrapper.style.transform = `scale(${scale})`;
            };
            setTimeout(fit, 100); window.addEventListener('resize', fit);
 
            // ── Observer: Handles multiple highlights & nesting (DIFFSEER'S SVG LOGIC PRESERVED) ──
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const stepIndex = parseInt(entry.target.dataset.index);
                        const step = this.steps[stepIndex];
 
                        // Update breadcrumb dots
                        document.querySelectorAll('.vw-bc-dot').forEach((dot, di) => {
                            dot.className = 'vw-bc-dot ' + (di < stepIndex ? 'done' : di === stepIndex ? 'current' : 'upcoming');
                        });
                        const numEl = document.getElementById('vw-bc-num');
                        if (numEl) numEl.textContent = stepIndex + 1;
 
                        // Update card active state
                        document.querySelectorAll('.vw-card').forEach(c => c.classList.remove('active'));
                        const activeCard = document.getElementById(`vw-card-${stepIndex}`);
                        if (activeCard) activeCard.classList.add('active');
 
                        // Narrate step text
                        if (this.narrationStarted && this.synth && !this.isMuted) {
                            this.synth.cancel();
                            const utter = new SpeechSynthesisUtterance(step.text);
                            utter.rate = 1.0;
                            this.synth.speak(utter);
                        }
 
                        // ── SELECT THE CORRECT SVG (DIFFSEER'S SPECIAL LOGIC — PRESERVED) ──
                        const allSvgs = document.querySelectorAll('svg');
                        let svg = null;
                        let maxScore = 0;
                        allSvgs.forEach(s => {
                            const rect = s.getBoundingClientRect();
                            const score = s.querySelectorAll("*").length + rect.width;
                            if (rect.width > 200 && score > maxScore) {
                                maxScore = score;
                                svg = s;
                            }
                        });
 
                        if (!svg) { console.error("Could not find the visualization SVG."); return; }
 
                        // Clear previous highlights
                        svg.querySelectorAll('.vw-dim, .vw-highlight').forEach(el => el.classList.remove('vw-dim', 'vw-highlight'));
 
                        // Highlight logic
                        if (step.actions && step.actions.some(a => a.includes('highlight'))) {
                            svg.querySelectorAll('g, rect, path, circle, text, line').forEach(el => el.classList.add('vw-dim'));
                            const selectors = this._resolveSelector(step.targets);
                            selectors.forEach(sel => {
                                const targets = svg.querySelectorAll(sel);
                                targets.forEach(el => {
                                    el.classList.remove('vw-dim');
                                    el.classList.add('vw-highlight');
                                    let p = el.parentElement;
                                    while (p && p !== svg) { p.classList.remove('vw-dim'); p = p.parentElement; }
                                });
                            });
                        }
                    }
                });
            }, { root: stepsScroll, threshold: 0.6 });
 
            document.querySelectorAll('.vw-step').forEach(el => observer.observe(el));
            this.scrollyObserver = observer;
        }
 
    _generalizeData(rawSteps) {
        const merged = new Map();
        
        const getTitle = (c, id) => {
            if (!c || !c.reason) return "Detail: " + id;
            // Cleans "Simulation Panel" or "Heatmap Bins" into nice Titles
            return c.reason.toLowerCase()
                .replace(/^(container for|view of|the)\s+/, '')
                .split(' and ')[0]
                .replace(/\b\w/g, l => l.toUpperCase());
        };
 
        const categorize = (txt) => {
            const b = { encoding: [], insight: [], interaction: [] };
            // Split sentences and bucket them by keyword
            (txt.match(/[^.?!]+[.?!]+|[^.?!]+$/g) || []).forEach(s => {
                const l = s.toLowerCase();
                if (l.match(/(click|hover|drag|load|select|update)/)) b.interaction.push(s.trim());
                else if (l.match(/(represent|encode|show|color|glyph|indicate)/)) b.encoding.push(s.trim());
                else b.insight.push(s.trim());
            });
            return { 
                encoding: b.encoding.join(' ') || "Visual encoding details.", 
                insight: b.insight.join(' ') || "Observe the patterns in this section.", 
                interaction: b.interaction.join(' ') || "Interact with this component to update the view." 
            };
        };
 
        rawSteps.forEach(step => {
            // Prioritize encoding selectors (Heatmap Bins) over view (Simulation Panel)
            let main = step.targets?.encoding?.candidates?.[0] || step.targets?.view?.candidates?.[0];
            let key = main ? main.selector : 'General_Overview';
            
            if (!merged.has(key)) {
                merged.set(key, { 
                    step_id: key, 
                    title: key === 'General_Overview' ? 'System Overview' : getTitle(main, step.step_id), 
                    rawText: '', 
                    selector: key 
                });
            }
            merged.get(key).rawText += ' ' + step.text;
        });
 
        return Array.from(merged.values()).map(e => ({ ...e, content: categorize(e.rawText) }));
    }
 
    _renderToggleBar() {
        if(document.getElementById('vw-toggle-bar')) return;
        const bar = document.createElement('div');
        bar.id = 'vw-toggle-bar';
        let html = `
            <button class="vw-toggle-btn" id="vw-btn-scrolly">
                <svg width="12" height="12" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="0" y="0" width="14" height="3" rx="1" fill="currentColor"/>
                    <rect x="0" y="5.5" width="10" height="2" rx="1" fill="currentColor" opacity="0.45"/>
                    <rect x="0" y="9.5" width="12" height="2" rx="1" fill="currentColor" opacity="0.45"/>
                </svg>
                Guided tour
            </button>
            <button class="vw-toggle-btn" id="vw-btn-explore">
                <svg width="12" height="12" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="7" cy="7" r="2.5" fill="currentColor"/>
                    <path d="M7 1v1.5M7 11.5V13M1 7h1.5M11.5 7H13M2.9 2.9l1.06 1.06M10.04 10.04l1.06 1.06M10.04 3.96l1.06-1.06M2.9 11.1l1.06-1.06" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>
                </svg>
                Free exploration
            </button>
            <div class="vw-toggle-divider"></div>
        `;
        if (this.isAuthorMode) {
            html += `
                <button class="vw-toggle-btn" id="vw-btn-edit">✎ Edit Text</button>
                <button class="vw-toggle-btn" id="vw-btn-export">💾 Export</button>
                <div class="vw-toggle-divider"></div>
            `;
        }
        html += `
            <button class="vw-audio-btn" id="vw-mute-btn" title="Toggle audio">
                <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2.5 5.5H1a.5.5 0 00-.5.5v4a.5.5 0 00.5.5h1.5l3.5 2.5V3L2.5 5.5z" fill="currentColor"/>
                    <path d="M9.5 5a3.2 3.2 0 010 6M11.5 3a5.8 5.8 0 010 10" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>
                </svg>
            </button>
        `;
        bar.innerHTML = html;
        document.body.appendChild(bar);
 
        document.getElementById('vw-btn-scrolly').onclick = () => this.setMode('scrolly');
        document.getElementById('vw-btn-explore').onclick = () => this.setMode('explore');
 
        const muteBtn = document.getElementById('vw-mute-btn');
        this.synth = window.speechSynthesis;
        this.isMuted = false;
        muteBtn.onclick = (e) => {
            this.isMuted = !this.isMuted;
            muteBtn.style.opacity = this.isMuted ? '0.35' : '1';
            if (this.isMuted && this.synth) this.synth.cancel();
        };
 
        if (this.isAuthorMode) {
            document.getElementById('vw-btn-edit').onclick = () => this.setMode('edit');
            document.getElementById('vw-btn-export').onclick = () => this.exportConfig();
        }
    }
}

if (typeof chrome !== "undefined" && chrome.runtime) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        
        if (request.action === "GENERATE_AND_LAUNCH") {
            const { description, code } = request.payload;
            
            console.log("📝 Received Context from Author:");
            console.log("Description:", description);
            console.log("Code provided:", code ? "Yes" : "No");
 
            // 1. Show "Generating..." Toast
            showLoadingToast();
 
            // 2. Simulate LLM Generation Delay (2 seconds)
            setTimeout(() => {
                removeLoadingToast();
 
                // 3. Initialize Tour
                if (window.visWalkthroughInstance) {
                    window.visWalkthroughInstance._teardown();
                }
                
                // Initialize with our RAW_STEPS (Simulating the result of the generation)
                window.visWalkthroughInstance = new VisWalkthrough({ steps: RAW_STEPS });
                
                // Store the author's input in the instance (for future export features)
                window.visWalkthroughInstance.authorContext = { description, code };
                
                window.visWalkthroughInstance.init();
                
                // Automatically start in Edit Mode since this is an Author flow
                window.visWalkthroughInstance.setMode('edit');
 
            }, 2000);
        }
    });
}
 
// --- Helper: Loading Toast UI ---
function showLoadingToast() {
    if(document.getElementById('vw-loading-toast')) return;
    const toast = document.createElement('div');
    toast.id = 'vw-loading-toast';
    toast.innerHTML = `
        <div style="display:flex; align-items:center; gap:10px;">
            <div class="vw-spinner"></div>
            <div>
                <div style="font-weight:bold; font-size:14px;">Analyzing Visualization...</div>
                <div style="font-size:11px; opacity:0.8;">Processing description & code context</div>
            </div>
        </div>
        <style>
            #vw-loading-toast {
                position: fixed; bottom: 30px; right: 30px; background: #2c3e50; color: white;
                padding: 15px 20px; border-radius: 8px; font-family: 'Segoe UI', sans-serif;
                box-shadow: 0 5px 20px rgba(0,0,0,0.3); z-index: 2147483647;
                animation: vw-slide-up 0.3s ease-out;
            }
            .vw-spinner { width: 16px; height: 16px; border: 2px solid rgba(255,255,255,0.3); border-top: 2px solid white; border-radius: 50%; animation: vw-spin 1s linear infinite; }
            @keyframes vw-spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
            @keyframes vw-slide-up { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        </style>
    `;
    document.body.appendChild(toast);
}
 
function removeLoadingToast() {
    const toast = document.getElementById('vw-loading-toast');
    if (toast) toast.remove();
}
 
const instance = new VisWalkthrough({ steps: RAW_STEPS });
    instance.init();
    instance.setMode('scrolly');
})();