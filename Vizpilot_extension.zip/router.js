// router.js
const vizMap = [
  {
    match: "https://www.jeffjianzhao.com/webapp/MatrixWave/matrixwave.html",
    file: "scripts/onboarding_matrixwave.js"
  },
  {
    match: "https://dongoa.github.io/VIStory/",
    file: "scripts/onboarding_vistory.js"
  },
  {
    match: "https://attentionflow.cmlab.dev/#/overview/artist/UComP_epzeKzvBX156r6pm1Q",
    file: "scripts/onboarding_attentionflow.js"
  },
  {
    match: "https://poloclub.github.io/dodrio/",
    file: "scripts/onboarding_dodrio.js"
  },
  {
    match: "https://vcg.github.io/upset/",
    file: "scripts/onboarding_upset.js"
  },
  {
    match: "https://diffseer.github.io/",
    file: "scripts/onboarding_diffseer.js"
  },
  {
    match: "https://www.jeffjianzhao.com/webapp/EgoLines/egolines-demo.html",
    file: "scripts/onboarding_egolines.js"
  },
  {
    match: "https://www.jeffjianzhao.com/webapp/Pearl/pearl.html",
    file: "scripts/onboarding_pearl.js"
  },
  {
    match: "https://quantumeyes.github.io/",
    file: "scripts/onboarding_quantum.js"
  },




];
// https://prettismart.onrender.com


const currentURL = window.location.href;

// Find which config matches the current URL
const activeViz = vizMap.find(item => currentURL.includes(item.match));

if (activeViz) {
  console.log("Router: Loading " + activeViz.file);
  
  // Create a script tag to inject the file
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL(activeViz.file);
  
  // This ensures the script runs in the context of the page
  (document.head || document.documentElement).appendChild(script);
  
  script.onload = function() {
    console.log("Router: Successfully loaded " + activeViz.file);
    this.remove(); // Clean up the tag after execution
  };
}